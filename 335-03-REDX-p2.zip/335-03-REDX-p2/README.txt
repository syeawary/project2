//Suhrab Yeawary and Aria Askaryar: Team RedX
//ariaaskaryar18@gmail.com  and  syeawary@csu.fullerton.edu 
//Project #2: Sort Race 
//CPSC 335-03

INTRODCUTION 

This program is made by Aria Askaryar and Suhrab Yeawary in html.
This program is a sort race which is a racing competition between three different types of sorting algorithms.
The race is between quicksort, Mergesort, and Goldporesort. As we can see Mergesort is the fastest with quicksort following in second. 
We tried our best as the current situation professor and since we are unable to go to campus for resources and office hours we were limited in our capability, 
however we still were able to complete the project after many hours of research and testing. Thank you. 
Quicksort: Goes through the array and swaps characters as it goes through. It does this multiple time until it is in order.
For example if we have an array filled with | 2 | 5 | 7 | 1 | 4 | 9 | 6 | there will be a left pointer and righter pointer checking if the element is in order if it is,
it moves to the next number but if it is not it will be swapped. So for example 2 and 6 will be compared and since 2 is smaller than 6 it is sorted and moved 
to the next element until it hits 4 and 7 which will be swapped. This is a relatively quick method for sorting. Merge Sort: Merge sort 
starts by separating the array into two sides one left and right side which will be sorted then they will be put together to have it all sorted. Merge sort is the fastest path to sorting. Similar to quicksort,
merge sort uses a divide and swap method which is efficient, user friendly, comparison-based sorting algorithm. Most implementations produce a stable sort, which means that the order of equal elements is the same in the input and output. 
Merge sort was invented in 1945 by John von Neumann as a divide and conquer algorithm. The slowest method of sorting was Goldporesort which takes its time by checking each variable in the array and comparing it to all variables in the array to sort. 
So, in conclusion we tested and discovered that mergesort was the fastest sorting method available and quicksort was the second fastest method, 
leaving Golds method as the slowest method.

*/

<html>
<head>
    <title>Sort Race </title>                            //title
    <h1 align = "center">Sort Race </h1>                     //organization
    <h2 align="center" >Made by Suhrab Yeawary and Aria Askaryar</h2>  //authors
    <h3 align="center"> Team Name: REDX, CPSC-335-03  Algorithms </h3> //team name/class
    <h2 align="center"> [ "F", "D","8", "A", "1", "5", "9", "3", "4", "7", "8", "5"]</h2> //alignment

    
</head>
<body style="color: blue;">                         //changes color to blue
    
    <div id = "content"                            
    style ="text-align: center;">
        <canvas id= "canvas" width="930" height="900"
        style="border:2px solid;">
        </canvas>

    </div>
    <style>
          
          #h2,h1                    //creates rainbow color on webpage
        {
          background-image: linear-gradient(to left, violet, indigo, green, orange, red);
          
        }
        #h1, h2{
          background-image: linear-gradient(to left, black, violet, black indigo, green, orange, red);
        }
        #h1, h3{
          background-image: linear-gradient(to left, violet, black, indigo, green, orange, red);
        }
      
      
    </style>
    
<script>

var canvas = document.getElementById("canvas");            //created canvas
var surface = canvas.getContext("2d");                //2 dimensional 

surface.beginPath();                            
surface.strokeStyle = 'black';        //default color
surface.lineWidth = 2;            //creates the width by 2

surface.stroke();            //draws the path you have defined

surface.moveTo(620, 0);        //positioning the path

surface.stroke();            //repeats

surface.font = '16px Arial';            //font
surface.fillText('QuickSort',120 , 15);        //variable numbers
surface.fillText('MergeSort',430 , 15);        //variable numbers    
surface.fillText('GoldPoresort',740 , 15);    //variable numbers

//--------------------Gold's Poresort---------------------------
var goldAr = [ "F", "D","8", "A", "1", "5", "9", "3", "4", "7", "8", "5"]; //chosen variables 
var state = 0;            //default state beginning the race

function GoldPoresort(ar){        

    var i, j, temp;        //temporary variable

    var size = ar.length;        //variable size is set to arc length

    hextoDec(ar);        //converts hex to decimal 

    for(i = 0; i+1 < size; i++){        //for loop which determines the race and how the function
        for(j = 0; j < size+state-2; j++)    // sorts 
        {
            if(ar[j] > ar[j+1])
            {
                temp = ar[j];            //temporary 
                ar[j] = ar[j+1];        //increments 
                ar[j+1] = temp;
            }
        }

        dectoHex(ar);                    //converts decimal to hex
        surface.fillText(" "+ ar, 700, (state-1)*50);    
        state++;
         if(state < ar.length){
        window.setTimeout(GoldPoresort, 1500, ar);    //Goldporesory increments and timesort 
        }
        else{
            window.clearTimeout();
        }
        break;
    }
       
        
}

//--------------------------Quick Sort-------------------------        
 
var quickAr = ["F", "D","8", "A", "1", "5", "9", "3", "4", "7", "8", "5"];
var numofLoops = 1;

function partition(items, left, right) {
    var temp;
    var pivot   = items[Math.floor((right + left) / 2)], 
        i       = left, 
        j       = right;
    while (i <= j) {
        while (items[i] < pivot) {
            i++;
        }
        while (items[j] > pivot) {
            j--;
        }
        if (i <= j) {
            temp = items[i];
            items[i] = items[j];
            items[j] = temp;
            i++;
            j--;
        }
    }
    return i;
}

function quickSort(ar, left, right) {
    var index;

    hextoDec(ar);

    if (ar.length > 1) {
        index = partition(ar, left, right); 

        dectoHex(ar);    
        surface.fillText("  "+ ar, 80, numofLoops*50);
            numofLoops++;

        if (left < index - 1) { 
            
            window.setTimeout(quickSort, 1500, ar, left, index - 1);
            
        }
        if (index < right) { 
            
            window.setTimeout(quickSort, 1500, ar, index, right);
        }
    }
}



//------------------------Merge Sort------------------------------------------

var mergeAr = ["F", "D","8", "A", "1", "5", "9", "3", "4", "7", "8", "5"];
var counter = 1;

surface.fillText(" "+ mergeAr, 390, counter*50);
            counter++;

function merge(leftAr, rightAr) {
var sortedAr = [];

  while (leftAr.length>0 && rightAr.length>0) {
    if (leftAr[0] < rightAr[0]) {
      sortedAr.push(leftAr[0]);
      leftAr = leftAr.slice(1)
   } else {
      sortedAr.push(rightAr[0]);
      rightAr = rightAr.slice(1)
     }
   }
  while (leftAr.length){
    sortedAr.push(leftAr.shift());
  }
  while (rightAr.length)
  {
    sortedAr.push(rightAr.shift());
  }

  surface.fillText( sortedAr, 390, counter*50);
            counter++;
  return sortedAr;
  
}

function mergesort(ar) {

  if (ar.length < 2) {
    return ar; 
    }
    else {
    
    var leftTemp = [];
    var rightTemp = [];
    var sortedTemp = [];

    var mid = parseInt(ar.length / 2);
    var leftAr   = ar.slice(0, mid);
    var rightAr  = ar.slice(mid, ar.length);

    leftTemp = mergesort(leftAr);

    rightTemp = mergesort(rightAr);
    
    sortedTemp = merge(leftTemp,rightTemp);
    
    return sortedTemp;

  }

}

function hextoDec(ar){

    for(var i = 0; i < ar.length; i ++)
    {
        var temp = ar[i];

        switch(temp){

            case "1":
                ar[i] = 1;
                break;
            case "2":
                ar[i] = 2;
                break;
            case "3":
                ar[i] = 3;
                break;
            case "4":
                ar[i] = 4;
                break;
            case "5":
                ar[i] = 5
                break;
            case "6":
                ar[i] = 6;
                break;
            case "7":
                ar[i] = 7;
                break;
            case "8":
                ar[i] = 8;
                break;
            case "9":
                ar[i] = 9;
                break;
            case "A": 
                ar[i] = 10;
                break;
            case "B":
                ar[i] = 11;
                break;
            case "C":
                ar[i] = 12;
                break;
            case "D":
                ar[i] = 13;
                break;
            case "E":
                ar[i] = 14;
                break;
            case "F":
                ar[i] = 15;
                break;
            default:
                break;
        }

    }
}

function dectoHex(ar){

    for(var i = 0; i < ar.length; i ++)
    {
        var temp = ar[i];

        switch(temp){

            case 1:
                ar[i] = "1";
                break;
            case 2:
                ar[i] = "2";
                break;
            case 3:
                ar[i] = "3";
                break;
            case 4:
                ar[i] = "4";
                break;
            case 5:
                ar[i] = "5"
                break;
            case 6:
                ar[i] = "6";
                break;
            case 7:
                ar[i] = "7";
                break;
            case 8:
                ar[i] = "8";
                break;
            case 9:
                ar[i] = "9";
                break;
            case 10: 
                ar[i] = "A";
                break;
            case 11:
                ar[i] = "B";
                break;
            case 12:
                ar[i] = "C";
                break;
            case 13:
                ar[i] = "D";
                break;
            case 14:
                ar[i] = "E";
                break;
            case 15:
                ar[i] = "F";
                break;
            default:
                break;
        }

    }
}

function rcMng(){
    window.addEventListener("load",GoldPoresort(goldAr));
    window.addEventListener("load",quickSort(quickAr,0, quickAr.length-1));
    window.addEventlistener("load", mergesort(mergeAr));
}

rcMng();

</script>
</body>
</html>

